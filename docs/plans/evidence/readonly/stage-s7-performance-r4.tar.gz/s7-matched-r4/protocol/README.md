# Matched native readonly measurement (s7-v2)

This is an optional overlay on the existing readonly native workload, not product
behavior. Use separate clean worktrees at exact baseline/candidate commits. The
installer rejects staged, unstaged and untracked inputs. It changes only the
Reader observation hook and the existing self-test entry point.

For each worktree:

1. Preserve its original Release executable.
2. `python3 scripts/readonly-matched/install_harness.py install --root ROOT --expected-sha SHA --receipt RECEIPT`
3. Build `codeinsight-app` in Release with the same Swift/SDK/libgit2 configuration.
4. `python3 scripts/readonly-matched/install_harness.py seal --root ROOT --receipt RECEIPT --binary BINARY`
5. Preserve the sealed executable, sibling resource bundles, receipt and build log.
6. `python3 scripts/readonly-matched/install_harness.py restore --root ROOT --receipt RECEIPT`

Run the installer from this checkout against the separate ROOT. Receipts/backups
belong in an ignored `.build` directory. Restore refuses to overwrite unexpected
edits. Sealing binds the binary/resource hashes to the controlled source overlay;
the app reports an embedded source SHA, not only a command-line label.

`run_matched.py --help` lists the binary/receipt/manifest/output arguments. Use
`--scenario all --samples 30 --max-pairs 45` for the fixed sequence. It alternates
AB/BA pairs, includes all six frozen inputs, retains raw exceptions/timeouts and
reports per-metric n/p50/nearest-rank-p95/max. Do not overlap builds or other native
benchmarks, or interact with measurement windows. These are fresh-process cold
samples; OS file/font caches are not flushed.

The measured window uses an explicit Aqua appearance and starts with the light
Reader theme; this changes no system/user preference and avoids automatic day/night
appearance changes invalidating a long collection. Appearance is recorded.

The sequence is cold display, identifier warm-up/hot interaction, scrolling,
fold/unfold, color, font, then combined color/font/wrap. A recorded setup outside
measurement clears occurrences and installs the same downstream caret before
projection/reflow. Correct full-selection preservation is tested separately.

The first native draw marker is a drawBackground callback, not compositor delivery.
Operation-only, operation plus synchronous drawing, and stable viewport latency
are separate. Both versions pump native turns and require matching content,
settings, fragment font attributes, selection, actual draw and no pending reflow.
Stable viewport geometry must repeat; elapsed time alone is never sufficient.
Cold display expects the initial zero-length caret at offset zero; a transient
pre-layout native selection is recorded separately and is not treated as intent.
Both receive the same 100ms post-readiness memory observation, excluded from
latency. Physical-footprint samples and their peak remain raw evidence.

One independent source-byte/row-offset target spans uninterrupted reflow updates.
Every readiness observation measures its actual laid-out row and legal-clamped
error. LAST production diagnostics cannot establish readiness. Only the same
known >8,000-line or >64 KiB source-paragraph policy can make exact anchor latency
NOT_RUN; content/draw/geometry convergence must still pass. Other missing or
misplaced targets remain failures. Empty/short-fold fixtures explicitly report
inapplicable folding instead of measuring a no-op.

Operation/draw and supported stable metrics each require 30 valid observations.
Deterministic stable failure is retained as FAIL after the other metrics reach
30; it does not trigger futile additional pairs or become a pass. Collection
completion is separate from validity. Cold p95 regressions require written review;
a capture alone is not release approval. Native host/whole-workflow acceptance,
source correctness, CI and lifecycle proofs remain separate.

### Explicit cold caret setup (r3)

The cold measured closure now sets caret `[0, 0]` with downstream affinity immediately after `reader.display`. Both standalone readers were observed returning an initial EOF caret; S0 later normalized it during native reflow while S6 retained it. Treating an assumed zero caret as intent made the earlier harness incomparable. The explicit setup models the host's initial caret action, is charged to cold operation time, and is recorded as `coldProtocolSetup`. Other phases continue to record actual post-operation selection. Preserve r1/r2 artifacts as protocol-development failures; do not merge them into r3 statistics.
